myApp.controller("bookEditController",function($scope,bookManage){
    

})