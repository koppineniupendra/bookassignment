myApp.service("bookManage",function(){
    this.bookDetails=[{imageurl:'bookImg1.jpg',bookId:6001,bookName:"you are the best friend",Author:"Ajay k Pandey",price:300,Description:"...."},
                    { imageurl:'bookImg2.jpg',bookId:6002,bookName:"one Day Life will change",Author:"Saranya Umakanthan ",price:200,Description:"...."},
                    { imageurl:'bookImg3.jpg',bookId:6003,bookName:"something i never told you",Author:"Shravya Bhinder",price:400,Description:"...."},];

    this.getAllBookDetails=function(){
        return this.bookDetails;
    }
   
    this.addBook=function(book)
    {
        this.bookDetails.push(book);
    }

    this.deleteBook=function(book){
        var pos=this.bookDetails.findIndex(item=> {
            if(item.bookId == book.bookId)
            {
                return true;
            }
            else
            {
                return false;
            }
        })

        this.bookDetails.splice(pos,1);
    }
})
