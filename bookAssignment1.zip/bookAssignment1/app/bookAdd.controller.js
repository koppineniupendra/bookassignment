myApp.controller("bookAddController",function($scope,bookManage){
   
    $scope.saveDetailsEventHandler=function(){
        bookManage.addBook($scope.newBook)
    }
    
})
